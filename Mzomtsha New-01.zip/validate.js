function validateTextbox(){
  var box = document.getElementById("Name");
  var box2 = document.getElementById("Email");
  var box3 = document.getElementById('Contribution')
}
if (box.value == "" || box2.value == "" || box3.value == "") {
  alert ("The field cannot be blank");
  return false;
}
