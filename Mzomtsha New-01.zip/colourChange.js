function changColor(newColor) {
  var elem = document.getElementById('navbar');
  elem.style.backgroundColor = newColor;
}
